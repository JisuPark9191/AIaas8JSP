package com.prac.myapp.client.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.prac.myapp.addr.model.ClientVO;

public interface IClientRepository {
	int getClientCount();
	List<ClientVO> getClientList(@Param("value")String value, @Param("orderby")String orderby);
	List<ClientVO> getClientNameList(String name);
	ClientVO getClientInfo(String id);
	void updateClient(ClientVO clnt);
	void insertClient(ClientVO clnt);
	void deleteClient(@Param("id")String id, @Param("pw")String pw);
}
